//
//  UserAuthorization.swift
//  RealtyNavi
//
//  Created by 顾振华 on 2018/4/18.
//  Copyright © 2018年 LanSi. All rights reserved.
//

import UIKit

/// 用户授权
struct UserAuthorization {
    static let settingUrl = openSettingURL

    private init() {
    }
}

extension UserAuthorization {
    /// 打开应用系统设置页面
    static func userAuthorization() {
        guard UIApplication.shared.canOpenURL(settingUrl) else {
            return
        }
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(settingUrl, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(settingUrl)
        }
    }

    private static var openSettingURL: URL {
        let openSettingsURLString: String
        #if swift(>=4.2)
        openSettingsURLString = UIApplication.openSettingsURLString
        #else
        openSettingsURLString = UIApplicationOpenSettingsURLString
        #endif
        return URL(string: openSettingsURLString)!
    }
}
